package routines;

/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class MsSql_To_MySql_Mapping {
	private String MsSqlServer_Type;
	private String MySql_Type_Mapping;
    private String IS_NUMERIC;
    private String IS_DATE;
    private String IS_CHAR;
    private String USE_BRACKET;
    private String IS_STATIC;
    private String VarChar_Max_Length;
    
    public MsSql_To_MySql_Mapping()
    {
    	this.MsSqlServer_Type = "";
    	this.MySql_Type_Mapping = "";
    	this.IS_NUMERIC = "";
    	this.IS_DATE = "";
    	this.IS_CHAR = "";
    	this.USE_BRACKET = "";
    	this.IS_STATIC = "";
    	this.VarChar_Max_Length = "";
    }
	public MsSql_To_MySql_Mapping(String MsSqlServer_Type, String MySql_Type_Mapping, String IS_NUMERIC, String IS_DATE, String IS_CHAR, String USE_BRACKET,String IS_STATIC,String VarChar_Max_Length){
		this.MsSqlServer_Type = MsSqlServer_Type;
		this.MySql_Type_Mapping = MySql_Type_Mapping;
		this.IS_NUMERIC = IS_NUMERIC;
		this.IS_DATE = IS_DATE;
		this.IS_CHAR = IS_CHAR;
		this.USE_BRACKET = USE_BRACKET;
		this.IS_STATIC = IS_STATIC;
		this.VarChar_Max_Length = VarChar_Max_Length;
	}
		
	public void setMsSqlServer_Type(String MsSqlServer_Type) {
		this.MsSqlServer_Type = MsSqlServer_Type;
	}
	
	public String getMsSqlServer_Type() {
		return MsSqlServer_Type;
	}
	
	public void setMySql_Type_Mapping(String MySql_Type_Mapping) {
		this.MySql_Type_Mapping = MySql_Type_Mapping;
	}
	
	public String getMySql_Type_Mapping() {
		return MySql_Type_Mapping;
	}
	
	public void setIS_NUMERIC(String IS_NUMERIC) {
		this.IS_NUMERIC = IS_NUMERIC;
	}
	
	public String getIS_NUMERIC() {
		return IS_NUMERIC;
	}
	
	public String getIS_DATE() {
		return IS_DATE;
	}
	
	public void setIS_DATE(String IS_DATE) {
		this.IS_DATE = IS_DATE;
	}
	
	
	public String getIS_CHAR() {
		return IS_CHAR;
	}
	
	public void setIS_CHAR(String IS_CHAR) {
		this.IS_CHAR = IS_CHAR;
	}
	
	public String getUSE_BRACKET() {
		return USE_BRACKET;
	}
	
	public void setUSE_BRACKET(String USE_BRACKET) {
		this.USE_BRACKET = USE_BRACKET;
	}
	
	public String getIS_STATIC() {
		return IS_STATIC;
	}
	
	public void setIS_STATIC(String IS_STATIC) {
		this.IS_STATIC = IS_STATIC;
	}
	
	public String getVarChar_Max_Length() {
		return VarChar_Max_Length;
	}
	
	public void setVarChar_Max_Length(String VarChar_Max_Length) {
		this.VarChar_Max_Length = VarChar_Max_Length;
	}
	public String Return_DDL(String Column_Name, String Data_Type, int Char_Length, String IS_NULL, java.util.Iterator<MsSql_To_MySql_Mapping> Mapping_Info)
	{
		String ToReturn_DDL="\n     ";
		while(Mapping_Info.hasNext())
		{
			MsSql_To_MySql_Mapping data = Mapping_Info.next();
			if(data.MsSqlServer_Type.toLowerCase().equals(Data_Type.toLowerCase()))
			{
				ToReturn_DDL = ToReturn_DDL + Column_Name + "   ";
				
				if(data.IS_NUMERIC.equals("YES") || data.IS_DATE.equals("YES"))
					ToReturn_DDL = ToReturn_DDL + data.MySql_Type_Mapping + (IS_NULL.equals("YES") ? "": " NOT NULL");
				else if(data.IS_CHAR.equals("YES"))
				{
					if(Char_Length<Integer.parseInt(data.VarChar_Max_Length))
					{
					ToReturn_DDL = ToReturn_DDL + data.MySql_Type_Mapping + "(" +  String.valueOf(Char_Length) + ")" + (IS_NULL.equals("YES") ? "": " NOT NULL");
					}
					else 
					{
						ToReturn_DDL = ToReturn_DDL + data.MySql_Type_Mapping + "(" + data.VarChar_Max_Length + ")" + (IS_NULL.equals("YES") ? "": " NOT NULL");
					}
				}
				else 
					ToReturn_DDL = ToReturn_DDL + data.MySql_Type_Mapping + (IS_NULL.equals("YES") ? "": " NOT NULL");
				
				return ToReturn_DDL;
			}
		}		
		
				ToReturn_DDL = ToReturn_DDL + Data_Type + (IS_NULL.equals("YES") ? "": " NOT NULL");
				return ToReturn_DDL;
	}
	
	
	public String Return_DML(String Column_Name, String Data_Type, int Char_Length, String IS_NULL, java.util.Iterator<MsSql_To_MySql_Mapping> Mapping_Info)
	{		
		String ToReturn_DML="\n     ";
		while(Mapping_Info.hasNext())
		{	
			
			MsSql_To_MySql_Mapping data = Mapping_Info.next();
			
			if(data.MsSqlServer_Type.toLowerCase().equals(Data_Type.toLowerCase()))
			{
				if(data.IS_NUMERIC.equals("YES"))
					ToReturn_DML = ToReturn_DML + "ISNULL([" + Column_Name + "],NULL)";
				else if(data.IS_DATE.equals("YES"))
					ToReturn_DML = ToReturn_DML + "ISNULL(CONVERT(varchar(19), ["+Column_Name+"], 120), NULL)";
				else if(data.IS_CHAR.equals("YES"))
					ToReturn_DML = ToReturn_DML + "ISNULL(QUOTENAME(["+Column_Name+"],\'\"\'), NULL)";
				//else 
				//	ToReturn_DML = ToReturn_DML + "ISNULL(QUOTENAME(["+Column_Name+"]\'\"\'), NULL)";				
				return ToReturn_DML;
			}
			
			
		}		
				return ToReturn_DML ;
		
					
	}
}
