package routines;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class SendEmail {

    /**
     * helloExample: not return value, only print "hello" + message.
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string("world") input: The string need to be printed.
     * 
     * {example} helloExemple("world") # hello world !.
     */
	
	public static void sendEmail(String MailBody)
	{
		String smtp_host = "10.107.24.88";//(String) globalMap.get("SMTP_SERVER");
		String smtp_port = "25";//Integer.toString((Integer) globalMap.get("SMTP_PORT"));

		//String to_name = "wahab.ali@trgworld.com"//input_row.EMAIL;
		String to_email = "moazamahmussarat.rubab@satmapinc.com";//input_row.EMAIL;
		String from_email = "no-reply@satmapinc.com";//(String) globalMap.get("EMAIL_SENDER");
		String subject = "[SATMAP|BSKYB] - Hourly Report";//input_row.SUBJECT;
		//String content = //input_row.CONTENT;

		String email_content = MailBody;

		try {
		// Fix Umlaute?
		System.setProperty("mail.mime.charset","Cp1252");

		// Setup Email
		Properties props = new Properties();
		props.put("mail.smtp.host", smtp_host);
		props.put("mail.smtp.port", smtp_port);

		Session session = Session.getDefaultInstance(props);
		MimeMessage email = new MimeMessage(session);

		// set subject
		email.setSubject(subject);
		email.setHeader("From", from_email);
		email.setSentDate(new java.util.Date());

		Address address = new InternetAddress(from_email);
		email.setFrom(address);

		Address toaddress = new InternetAddress(to_email);
		email.addRecipient(Message.RecipientType.TO, toaddress);

		// creates message part
		MimeBodyPart messageBodyPart = new MimeBodyPart();
		messageBodyPart.setContent(email_content, "text/html");


		// off we go!
		Transport.send(email);

		} catch (Exception e) {
			e.printStackTrace();
		//throw new Exception(e);
		}
	}
    public static void helloExample(String message) {
        if (message == null) {
            message = "World"; //$NON-NLS-1$
        }
        System.out.println("Hello " + message + " !"); //$NON-NLS-1$ //$NON-NLS-2$
    }
    
    public static void sendHtmlEmail(String mailBody){
    	// Recipient's email ID needs to be mentioned.
        String to = "moazamahmussarat.rubab@satmapinc.com";

        // Sender's email ID needs to be mentioned
        String from = "no-reply@satmapinc.com";

        // Assuming you are sending email from localhost
        String host = "10.105.11.52";

        // Get system properties
        Properties properties = System.getProperties();

        // Setup mail server
        properties.setProperty("10.107.24.88", host);

        // Get the default Session object.
        Session session = Session.getDefaultInstance(properties);

        try{
           // Create a default MimeMessage object.
           MimeMessage message = new MimeMessage(session);

           // Set From: header field of the header.
           message.setFrom(new InternetAddress(from));

           // Set To: header field of the header.
           message.addRecipient(Message.RecipientType.TO,
                                    new InternetAddress(to));

           // Set Subject: header field
           message.setSubject("[SATMAP|BSKYB] - Hourly Report");

           // Send the actual HTML message, as big as you like
           message.setContent(mailBody,
                              "text/html" );

           // Send message
           Transport.send(message);
           System.out.println("Sent message successfully....");
        }catch (MessagingException mex) {
           mex.printStackTrace();
        }
    	
    }
}
