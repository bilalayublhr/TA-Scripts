package routines;
public class Generic_Html_Alert {
	private static String Final_Output;
    private static String driverName = "com.mysql.jdbc.Driver";   
    private static java.sql.Connection con;
    private static java.sql.Statement stmt;
    private static java.sql.ResultSet rs;
    
    //Properties related to Connection
    private static String DbIP;
    private static String DbPort;
    private static String DbName;
    private static String DbUsername;
    private static String DbPassword;
    
    //Alert Specific Generic Properties
    private static boolean Is_Alert_Complete;
    private static String Comma_Seperated_Warning_Columns;
    private static String Custom_CSS_Styling;
    private static String Query;
    private static String Table_Heading;
    
    /**
     * Return HTML in a string which can be used to send Email Alert based on the parameters sent to this function
     *
     * {talendTypes} String
     *
     * {Category} Afiniti-ETL-Custom
     *
     * {param} string("localhost") DbConnection_IP: string
     *
     * {param} string("3307") DbConnection_Port: string
     * 
     * {param} string("etqsatmap") DbConnection_DatabaseName: string
     * 
     * {param} string("etl_user") DbConnection_Username: string
     * 
     * {param} string("etl_password") DbConnection_Password: string
     * 
     * {param} string("select * from etqsatmp.agent_appointments;") Query_To_Execute: string
     * 
     * {param} string(".table{width:100%; border-collapse:collapse; }") Custom_Html_Css: string
     * 
     * {param} string("File Loading Statistics Alert") Alert_Heading: string
     * 
     * {param} string("File Loading Statistics Alert") Alert_Heading: string
     * 
     * {param} string(true) Is_Complete_Alert: boolean
     * 
     * {param} string("0") Warning_Columns: string
     * {example} Generic_Html_alert("10.32.8.148", "3307", "etqsatmap", "etl_user", "Password","CALL `etqsatmap`.`TRN_Alert`()",".table{width:100%; border-collapse:collapse; }.table tr{ background:#b8d1f3; width:100%; }","TRN Loading Alert",true,"2,3")
     *
     */
    public static String Generate_Alert(String DbConnection_IP,String DbConnection_Port,String DbConnection_DatabaseName,String DbConnection_Username,String DbConnection_Password,String Query_To_Execute,String Custom_Html_Css,String Alert_Heading,boolean Is_Complete_Alert, String Warning_Columns)
    {
   	 DbIP = DbConnection_IP;
   	 DbPort= DbConnection_Port;
   	 DbName=DbConnection_DatabaseName;
   	 DbUsername=DbConnection_Username;
   	 DbPassword=DbConnection_Password;
   	 Is_Alert_Complete = Is_Complete_Alert;
   	 Comma_Seperated_Warning_Columns = Warning_Columns;
   	 Query = Query_To_Execute;
   	 Custom_CSS_Styling = Custom_Html_Css;
   	 Table_Heading = Alert_Heading;
   	 Final_Output="";
   		 
   		try
    	{
   			Create_Connection();
      		int ToalQueryColumns = 0;
   			stmt = con.createStatement();
   			boolean isResultSet  = stmt.execute(Query);
   			while(true) 
   			{
   				if(isResultSet)
   				{
    		        rs = stmt.getResultSet();
    		        java.sql.ResultSetMetaData metaData = rs.getMetaData();
    		    	ToalQueryColumns = metaData.getColumnCount(); 
    		        Final_Output = CreateCompleteAlert(CreateTableHeaders(metaData),CreateTableBody(rs,ToalQueryColumns));   		    	 
    		        rs.close();
    		    } 
    		    else 
    		    {
    		        if(stmt.getUpdateCount() == -1) 
    		        {
    		            break;
    		        }
    		    }

    		    isResultSet = stmt.getMoreResults();
   			}  		
   	 }
   	 catch(Exception ex)
   	 {
   		 System.out.println(ex.getMessage());
   	 }
   	 finally
   	 {
   		 try{CloseConnections();} catch(Exception ex){System.out.println(ex.getMessage());}
   	 }
   	 
   	 return Final_Output;
    }
    
    private static void Create_Connection()  throws Exception
    {
          try {
              Class.forName(driverName);
              try {
                  con = java.sql.DriverManager.getConnection("jdbc:mysql://"+DbIP+":"+DbPort+"/"+DbName+"?allowMultiQueries=true", DbUsername, DbPassword); 
                 
              } catch (java.sql.SQLException ex) {
                  throw new Exception("Failed to create the database connection. Error Message\n"+ex.getMessage());    
              }
          } catch (ClassNotFoundException ex) {
          	throw new Exception("Driver not found. Error Message\n"+ex.getMessage()); 
          }       
      }
    private static void CloseConnections() throws Exception
    {    	
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (con != null) con.close();               

            }
            catch (java.sql.SQLException sqlee) {
            	throw new Exception("Error in closing connection.Error Message\n"+sqlee.getMessage());
            }    
    }
    private static String CreateTableHeaders(java.sql.ResultSetMetaData Columns) throws Exception
    {
    	String TableHeaders = "\t<tr>\n";
    	
    	try
    	{
    	for (int i = 1; i <= Columns.getColumnCount(); i++) TableHeaders += "\t\t<th>"+Columns.getColumnLabel(i)+"</th>\n";
    	}
    	catch(java.sql.SQLException e)
    	{
    		throw new Exception("Error in Retreiving/Creating Column Names. Error Message\n"+e.getMessage());
    	}
    	return TableHeaders+"\t</tr>";
    }
    private static String CreateTableBody(java.sql.ResultSet Body,int totalcolumns) throws Exception
    {
    	String TableCells = "";
    	boolean isWaning_Generatable=false ;
    	String[] Comma_Sperated_cols;
    	int first_col_index=1;
    	int second_col_index=1;
    	if(!Comma_Seperated_Warning_Columns.equals("0"))
    	{
    	Comma_Sperated_cols = Comma_Seperated_Warning_Columns.split("\\s*,\\s*"); //Additionally removing unintenional spaces put between comma seperated values
    	first_col_index = Integer.parseInt(Comma_Sperated_cols[0]);
    	second_col_index = Integer.parseInt(Comma_Sperated_cols[1]);
    	isWaning_Generatable=true;
    	}
    	try
    	{
    	while(Body.next())
    	{
    		TableCells += "\n\t<tr>\n";
    		for (int i=1;i<=totalcolumns;i++) 
    		{
    			if(isWaning_Generatable&&(!Body.getString(first_col_index).equals(Body.getString(second_col_index)))) 
    				TableCells+="\t\t<td bgcolor=#FF0000>"+Body.getString(i)+"</td>\n"; 
    			else 
    				TableCells+="\t\t<td>"+Body.getString(i)+"</td>\n";;
    		}
    		
    		TableCells+="\t</tr>";   		
    	}
    	}
    	catch(java.sql.SQLException e)
    	{
    		throw new Exception("Error occured while creating body. Error Message \n"+e.getMessage());
    	}
    	return TableCells;
    }
    private static String CreateCompleteAlert(String Headers,String Body)
    {
    	String Complete_Html = "";
    	String Table_Heading_HTML = "<h3 style=\"text-align:center\">"+Table_Heading+" </h3>";
    	String Table_Ending_Tags_HTML = "\n\n</body>\n</html>";
    	if(Is_Alert_Complete)
    	{
    	Complete_Html = "<html>\n<head>\n<style>\n";
    	Complete_Html +=Custom_CSS_Styling +"\n</style>\n</head>\n\n<body>\n\n";
    	Complete_Html +=Table_Heading_HTML+"\n<table style=\"width:100%\" class=\"table\">\n"+Headers+"\n"+Body+"</table>";
    	Complete_Html +=Table_Ending_Tags_HTML;  	
    	}
    	else
    	{
    		Complete_Html +=Table_Heading_HTML+"\n<table style=\"width:100%\" class=\"table\">\n"+Headers+"\n"+Body+"</table>";
    	}   	
    	return Complete_Html;
    }
}
